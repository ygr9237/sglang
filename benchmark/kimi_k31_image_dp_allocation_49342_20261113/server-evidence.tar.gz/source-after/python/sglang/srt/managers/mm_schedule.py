"""Multimodal embedding scheduling and cache coordination."""

import logging
from abc import ABC, abstractmethod
from contextlib import nullcontext
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

import torch

from sglang.srt.managers.req_types import MultimodalDataItem
from sglang.srt.mem_cache.multimodal_cache import EmbeddingResult, MultiModalStaticCache
from sglang.srt.multimodal.evs import EVSEmbeddingResult
from sglang.srt.multimodal.image_dp_consensus import (
    image_dp_coordinator,
    image_dp_group,
)
from sglang.srt.multimodal.transport.cuda_ipc import BORROW_CUDA_IPC_FEATURE_KEY
from sglang.srt.runtime_context import get_schedule
from sglang.srt.utils import is_hip, is_npu, is_xpu
from sglang.srt.utils.async_probe import maybe_assert_sum

logger = logging.getLogger(__name__)

_is_hip = is_hip()
_is_npu = is_npu()
_is_xpu = is_xpu()

embedding_cache: Optional[MultiModalStaticCache] = None
host_offload_event: Optional[torch.cuda.Event] = None


def init_mm_embedding_cache(max_size: int = 0):
    global embedding_cache
    embedding_cache = MultiModalStaticCache(max_size)


def get_embedding_chunk(
    embedding: torch.Tensor,
    extend_prefix_len: int,
    extend_seq_len: int,
    items_offset: List[Tuple[int, int]],
) -> Tuple[torch.Tensor, int, int]:
    """
    Extract a chunk of embeddings based on the specified prefix length, sequence length, and offset ranges.

    Args:
        embedding: The full embedding tensor to extract a chunk from
        extend_prefix_len: The starting position (prefix length) for extraction
        extend_seq_len: The number of tokens to extract
        items_offset: List of [start, end] offset ranges for multimodal items in the input sequence

    Returns:
        A tuple containing:
        - The extracted embedding chunk as a tensor
        - The start index used for extraction
        - The end index used for extraction

    Note:
        If there's no overlap between the requested range and the offset ranges,
        an empty tensor is returned with zeros for start and end indices.
    """
    start_index, end_index = 0, 0
    extend_start_index = extend_prefix_len
    extend_end_index = extend_prefix_len + extend_seq_len - 1

    for start, end in items_offset:
        if extend_start_index >= start and extend_start_index <= end:
            start_index += extend_start_index - start
        elif extend_start_index > end:
            start_index += end - start + 1

        if extend_end_index >= start and extend_end_index <= end:
            end_index += extend_end_index - start + 1
        elif extend_end_index > end:
            end_index += end - start + 1
    # some models' embedding is 3-dim, reshape it to 2-dim
    embedding = embedding.reshape(-1, embedding.shape[-1])
    embedding_chunk = embedding[start_index:end_index]
    return embedding_chunk, start_index, end_index


def _get_precomputed_embedding(
    items: List[MultimodalDataItem],
    items_size: List[int],
    prefix_length: List[int],
    extend_length: List[int],
    items_offset_list: List[List[Tuple[int, int]]],
) -> Optional[torch.Tensor]:
    """
    If all items have precomputed_embeddings, return their concatenation.
    If some but not all have precomputed_embeddings, raise NotImplementedError.
    If none have precomputed_embeddings, return None.
    """
    if host_offload_event is not None and any(
        isinstance(item.precomputed_embeddings, torch.Tensor)
        and item.precomputed_embeddings.is_cpu
        for item in items
    ):
        host_offload_event.synchronize()
    precomputed_embeddings = []
    max_iterations = min(len(items_size) - 1, len(prefix_length))

    for i in range(max_iterations):
        if items_size[i] == items_size[i + 1]:
            continue

        items_per_req = items[items_size[i] : items_size[i + 1]]
        extend_len = extend_length[i] if i < len(extend_length) else 0

        if any(item.precomputed_embeddings is None for item in items_per_req):
            chunk = None
        else:
            chunk = [
                get_embedding_chunk(
                    item.precomputed_embeddings,
                    prefix_length[i],
                    extend_len,
                    item.offsets,
                )[0]
                for item in items_per_req
            ]

        if chunk is None and len(items_per_req) > 1:
            return None
        precomputed_embeddings.append(chunk)

    if any(feature is not None for feature in precomputed_embeddings):
        if not all(feature is not None for feature in precomputed_embeddings):
            raise NotImplementedError(
                "MM inputs where only some items are precomputed."
            )

        precomputed_embeddings = [
            tensor for chunks in precomputed_embeddings for tensor in chunks
        ]
        # Normalize device across chunks before concat.
        target_device = next(
            (t.device for t in precomputed_embeddings if t.is_cuda),
            precomputed_embeddings[0].device,
        )
        precomputed_embeddings = [
            t if t.device == target_device else t.to(target_device, non_blocking=True)
            for t in precomputed_embeddings
        ]
        result = (
            precomputed_embeddings[0]
            if len(precomputed_embeddings) == 1
            else torch.concat(precomputed_embeddings)
        )
        # some models embedding is 3-dim, reshape it to 2-dim (similar to get_embedding_chunk)
        result = result.reshape(-1, result.shape[-1])
        return result
    return None


# A modality's embedding function. May return the combined [tokens, hidden]
# tensor, an EVSEmbeddingResult, or one tensor per input item. The per-item
# form lets encoders that naturally produce per-item outputs (e.g. a wav
# AutoEncoder looping over clips) skip an encoder-side torch.cat that
# per-item consumers (_get_chunked_embedding_by_item) would immediately
# split back apart — and each cached entry then owns its storage instead of
# being a view pinning the concatenated buffer.
DataEmbeddingFunc = Callable[
    [List[MultimodalDataItem]],
    torch.Tensor | List[torch.Tensor] | EVSEmbeddingResult,
]


class PrefetchedEmbeddingFunc(ABC):
    """A ``DataEmbeddingFunc`` that already holds some items' embeddings.

    The per-image paths take a held embedding in place of a vision pass.
    """

    @abstractmethod
    def __call__(
        self, items: List[MultimodalDataItem]
    ) -> torch.Tensor | List[torch.Tensor] | EVSEmbeddingResult:
        """Encode ``items`` that hold no embedding."""

    @abstractmethod
    def has_prefetched(self) -> bool:
        """Whether any embedding is held; lets the lookups below be skipped."""

    @abstractmethod
    def prefetched(
        self, item_key: Optional[bytes], token_count: int
    ) -> Optional[torch.Tensor]:
        """The held ``[token_count, hidden]`` embedding of an item, or None."""


def _prefetched_source(
    data_embedding_func: DataEmbeddingFunc,
) -> Optional[PrefetchedEmbeddingFunc]:
    if (
        isinstance(data_embedding_func, PrefetchedEmbeddingFunc)
        and data_embedding_func.has_prefetched()
    ):
        return data_embedding_func
    return None


def _flatten_embedding_result(
    embedding: torch.Tensor | List[torch.Tensor],
) -> torch.Tensor:
    """Normalize a DataEmbeddingFunc result to one [tokens, hidden] tensor."""
    if isinstance(embedding, list):
        if not embedding:
            raise ValueError(
                "DataEmbeddingFunc returned an empty per-item list; expected "
                "one entry per input item"
            )
        flat = [e.reshape(-1, e.shape[-1]) for e in embedding]
        return flat[0] if len(flat) == 1 else torch.cat(flat, dim=0)
    return embedding


def _embedding_token_count(embedding: torch.Tensor) -> int:
    """Return the number of multimodal tokens represented by an embedding."""
    # Vision encoders may return [tokens, hidden] or a higher-rank tensor.  The
    # scheduler always consumes the flattened token dimension.
    return embedding.reshape(-1, embedding.shape[-1]).shape[0]


def _discard_mismatched_cached_embedding(
    cache_key: Optional[int],
    expected_token_count: int,
    cached_token_count: int,
) -> None:
    """Log and remove a cache entry that cannot serve the current item."""
    logger.warning(
        "Discarding cached multimodal embedding due to a token-count mismatch: "
        "cache_key=%s, expected_tokens=%d, cached_tokens=%d. Recomputing embedding.",
        cache_key,
        expected_token_count,
        cached_token_count,
    )
    embedding_cache.free(cache_key, None)


def _can_skip_pre_embed_feature_move(data_embedding_func: DataEmbeddingFunc) -> bool:
    """Models that materialize and batch visual features inside their encoder.

    instead of performing multiple H2D for each mm feature from all mm_items (followed by concatenation on device),
    for some models which internally performs H2D on concated mm feature, these small H2D calls could be replaced with a single big H2D
    """
    owner = getattr(data_embedding_func, "__self__", None)
    if owner is None:
        return False
    if getattr(data_embedding_func, "__name__", None) not in (
        "get_image_feature",
        "get_video_feature",
    ):
        return False
    return owner.__class__.__name__ in {
        "Qwen3VLForConditionalGeneration",
        "Qwen3VLMoeForConditionalGeneration",
        "Qwen3_5ForConditionalGeneration",
        "Qwen3_5MoeForConditionalGeneration",
        "KimiK25ForConditionalGeneration",
        "KimiK3ForConditionalGeneration",
        "KimiK31ForConditionalGeneration",
    }


def _move_items_to_device(
    items: List[MultimodalDataItem],
    device: torch.device,
    data_embedding_func: DataEmbeddingFunc,
) -> None:
    """Wait for feature readiness and upload unless the encoder defers the move."""
    defer_move = _can_skip_pre_embed_feature_move(data_embedding_func)
    if host_offload_event is not None and any(
        isinstance(item.feature, torch.Tensor) and item.feature.is_cpu for item in items
    ):
        if defer_move or device.type != "cuda":
            # Deferred encoders can read CPU subsets of a mixed-device batch.
            host_offload_event.synchronize()
        else:
            torch.cuda.current_stream(device).wait_event(host_offload_event)
    if defer_move:
        return
    for item in items:
        if isinstance(item.feature, torch.Tensor) and item.feature.device != device:
            item.feature = item.feature.to(device, non_blocking=True)


def _item_overlap(
    item: MultimodalDataItem, chunk_start: int, chunk_end: int
) -> Optional[int]:
    """Token count of an item with several runs, or None if none intersects the chunk."""
    if len(item.offsets) == 1:
        start, end = item.offsets[0]
        return end - start + 1 if end >= chunk_start and start < chunk_end else None
    if any(end >= chunk_start and start < chunk_end for start, end in item.offsets):
        return sum(end - start + 1 for start, end in item.offsets)
    return None


def _slice_item_chunk(
    emb: torch.Tensor, item: MultimodalDataItem, chunk_start: int, chunk_len: int
) -> torch.Tensor:
    if len(item.offsets) == 1:
        start, end = item.offsets[0]
        local_start = max(start, chunk_start) - start
        return emb[local_start : min(end + 1, chunk_start + chunk_len) - start]
    return get_embedding_chunk(emb, chunk_start, chunk_len, item.offsets)[0]


def _get_chunked_embedding_full(
    data_embedding_func: DataEmbeddingFunc,
    embedding_items_per_req: List[MultimodalDataItem],
    items_offset: List[Tuple[int, int]],
    extend_prefix_len: int,
    extend_seq_len: int,
    input_ids: torch.Tensor,
    device: torch.device,
) -> Tuple[Optional[torch.Tensor], torch.Tensor]:
    """
    Fallback: encode all items at once, cache combined result, extract chunk.
    Used for non-bundled items or EVS results.
    """
    item_hashes = [item.cache_key for item in embedding_items_per_req]
    embedding_items_hash = MultiModalStaticCache.combine_hashes(item_hashes)
    embedding_per_req = embedding_cache.get(
        item_hashes, combined_hash=embedding_items_hash
    )

    # A compact feature hash can collide for inputs with different token
    # counts.  Never feed a stale cache entry into the scheduler: the length
    # mismatch would otherwise surface much later in _adjust_embedding_length
    # as an unrecoverable prefill crash.
    if embedding_per_req is not None and not isinstance(
        embedding_per_req, EVSEmbeddingResult
    ):
        expected_token_count = sum(end - start + 1 for start, end in items_offset)
        cached_token_count = _embedding_token_count(embedding_per_req.embedding)
        if cached_token_count != expected_token_count:
            _discard_mismatched_cached_embedding(
                embedding_items_hash, expected_token_count, cached_token_count
            )
            embedding_per_req = None

    coordinator = image_dp_coordinator(data_embedding_func)
    if coordinator is not None:
        descriptor = ("full", tuple(item_hashes), tuple(items_offset))
        if coordinator.reconcile((descriptor,), [embedding_per_req is None])[0]:
            if embedding_per_req is not None:
                embedding_cache.free(embedding_items_hash, None)
            embedding_per_req = None

    if embedding_per_req is None:
        with coordinator.encoding() if coordinator is not None else nullcontext():
            _move_items_to_device(embedding_items_per_req, device, data_embedding_func)
            embedding = data_embedding_func(embedding_items_per_req)
            if isinstance(embedding, list):
                # This path caches the combined per-request embedding, so the
                # per-item form is flattened here.
                embedding = _flatten_embedding_result(embedding)
            embedding_per_req = (
                EmbeddingResult(embedding=embedding)
                if isinstance(embedding, torch.Tensor)
                else embedding
            )
            embedding_cache.set(embedding_items_hash, embedding_per_req)

    # cache hits keep raw-input leases until request cleanup for eviction/re-prefill

    if isinstance(embedding_per_req, EVSEmbeddingResult):
        item = embedding_items_per_req[0]
        input_ids, items_offset = (
            embedding_per_req.redistribute_pruned_frames_placeholders(
                input_ids,
                items_offset,
                item=item,
                extend_prefix_len=extend_prefix_len,
                extend_seq_len=extend_seq_len,
            )
        )

    embedding_per_req_chunk, _, _ = get_embedding_chunk(
        embedding=embedding_per_req.embedding,
        extend_prefix_len=extend_prefix_len,
        extend_seq_len=extend_seq_len,
        items_offset=items_offset,
    )
    return embedding_per_req_chunk, input_ids


@dataclass
class PerImageRequestInfo:
    """Metadata for a single request using the per-image encoding path."""

    req_idx: int
    items: List[MultimodalDataItem]
    items_offset: List[Tuple[int, int]]
    extend_prefix_len: int
    extend_seq_len: int
    overlapping: List[Tuple[int, MultimodalDataItem, int]] = field(default_factory=list)


def _batch_encode_per_image_misses(
    data_embedding_func: DataEmbeddingFunc,
    per_image_requests: List[PerImageRequestInfo],
    device: torch.device,
) -> Dict[Tuple[bytes, int], torch.Tensor]:
    """
    Collect cache misses across ALL per-image requests, deduplicate by hash and
    expected token count, encode in a single ViT call, and populate the cache.

    Returns:
        hash_to_embedding: mapping from (item.cache_key, token_count) to its full
            embedding tensor.  Including the token count prevents two
            colliding hashes with different placeholder spans from being
            deduplicated within the same batch.
    """
    unique_misses: Dict[Tuple[bytes, int], Tuple[MultimodalDataItem, int]] = {}
    hash_to_embedding: Dict[Tuple[bytes, int], torch.Tensor] = {}

    prefetched = _prefetched_source(data_embedding_func)
    coordinator = image_dp_coordinator(data_embedding_func)
    all_items = {}

    # Phase 1a: find overlapping items per request and collect cache misses
    for req_info in per_image_requests:
        chunk_start = req_info.extend_prefix_len
        chunk_end = chunk_start + req_info.extend_seq_len  # exclusive
        overlapping = []
        if req_info.extend_seq_len > 0:
            for idx, item in enumerate(req_info.items):
                token_count = _item_overlap(item, chunk_start, chunk_end)
                if token_count is not None:
                    overlapping.append((idx, item, token_count))
        req_info.overlapping = overlapping

        for _idx, item, expected_token_count in overlapping:
            cache_key = (item.cache_key, expected_token_count)
            if coordinator is not None:
                all_items.setdefault(cache_key, (item, expected_token_count))
            if cache_key in hash_to_embedding:
                continue
            if prefetched is not None:
                early = prefetched.prefetched(item.cache_key, expected_token_count)
                if early is not None:
                    hash_to_embedding[cache_key] = early
                    continue
            cached = embedding_cache.get_single(item.cache_key)
            if cached is not None:
                cached_embedding = cached.embedding
                cached_token_count = _embedding_token_count(cached_embedding)
                if cached_token_count == expected_token_count:
                    hash_to_embedding[cache_key] = cached_embedding
                else:
                    _discard_mismatched_cached_embedding(
                        item.cache_key, expected_token_count, cached_token_count
                    )
                    unique_misses[cache_key] = (item, expected_token_count)
            elif cache_key not in unique_misses:
                if (
                    item.offsets[0][0] >= chunk_start
                    and item.offsets[-1][1] < chunk_end
                    and item.can_defer_cuda_ipc_feature_reconstruction()
                ):
                    item.model_specific_data[BORROW_CUDA_IPC_FEATURE_KEY] = True
                unique_misses[cache_key] = (item, expected_token_count)

    if coordinator is not None:
        keys = tuple(all_items)
        missing = coordinator.reconcile(keys, [key in unique_misses for key in keys])
        unique_misses = {
            key: all_items[key] for key, miss in zip(keys, missing) if miss
        }
        for key in unique_misses:
            if hash_to_embedding.pop(key, None) is not None:
                embedding_cache.free(key[0], None)

    # Phase 1b: single ViT call for all unique cache misses
    if unique_misses:
        with coordinator.encoding() if coordinator is not None else nullcontext():
            ordered_cache_keys = list(unique_misses.keys())
            miss_items = [unique_misses[key][0] for key in ordered_cache_keys]
            token_counts = [unique_misses[key][1] for key in ordered_cache_keys]

            _move_items_to_device(miss_items, device, data_embedding_func)
            all_miss_embedding = data_embedding_func(miss_items)

            if isinstance(all_miss_embedding, list):
                # Per-item embeddings: no split needed, and each cache entry owns
                # its storage (a torch.split view would pin the whole concatenated
                # buffer for as long as any single item stays cached). Mirrors
                # _get_chunked_embedding_by_item.
                assert len(all_miss_embedding) == len(miss_items), (
                    f"per-item embedding count {len(all_miss_embedding)} != "
                    f"cache-miss item count {len(miss_items)}"
                )
                split_embeddings = [
                    emb.reshape(-1, emb.shape[-1]) for emb in all_miss_embedding
                ]
            else:
                all_miss_embedding = all_miss_embedding.reshape(
                    -1, all_miss_embedding.shape[-1]
                )
                split_embeddings = torch.split(all_miss_embedding, token_counts, dim=0)
            for cache_key, emb in zip(ordered_cache_keys, split_embeddings):
                if embedding_cache.set(cache_key[0], EmbeddingResult(embedding=emb)):
                    cached = embedding_cache.get_single(cache_key[0])
                    if _embedding_token_count(cached.embedding) == cache_key[1]:
                        emb = cached.embedding
                # Keep a local ref (no extra GPU memory) so assembly never fails due to LRU eviction.
                hash_to_embedding[cache_key] = emb

    return hash_to_embedding


def _get_chunked_embedding_by_item(
    data_embedding_func: DataEmbeddingFunc,
    embedding_items_per_req: List[MultimodalDataItem],
    extend_prefix_len: int,
    extend_seq_len: int,
    device: torch.device,
) -> List[torch.Tensor]:
    """
    Return ordered item slices for one request's chunk.
    Items must already be split per image; an audio item may span several runs.
    """
    chunk_start = extend_prefix_len
    chunk_end = extend_prefix_len + extend_seq_len  # exclusive

    if extend_seq_len <= 0:
        return []

    overlapping = []
    for idx, item in enumerate(embedding_items_per_req):
        token_count = _item_overlap(item, chunk_start, chunk_end)
        if token_count is not None:
            overlapping.append((idx, item, token_count))

    if not overlapping:
        return []

    cached_embeddings = {}
    miss_items = []
    prefetched = _prefetched_source(data_embedding_func)
    for idx, item, expected_token_count in overlapping:
        if prefetched is not None:
            early = prefetched.prefetched(item.cache_key, expected_token_count)
            if early is not None:
                cached_embeddings[idx] = early
                continue
        cached = embedding_cache.get_single(item.cache_key)
        if cached is not None:
            cached_embedding = cached.embedding
            cached_token_count = _embedding_token_count(cached_embedding)
            if cached_token_count == expected_token_count:
                cached_embeddings[idx] = cached_embedding
            else:
                _discard_mismatched_cached_embedding(
                    item.cache_key, expected_token_count, cached_token_count
                )
                miss_items.append((idx, item, expected_token_count))
        else:
            miss_items.append((idx, item, expected_token_count))

    coordinator = image_dp_coordinator(data_embedding_func)
    if coordinator is not None:
        keys = tuple(
            (item.cache_key, count, index) for index, item, count in overlapping
        )
        missing = coordinator.reconcile(
            keys, [index not in cached_embeddings for index, _, _ in overlapping]
        )
        miss_items = [entry for entry, miss in zip(overlapping, missing) if miss]
        for index, item, _ in miss_items:
            if cached_embeddings.pop(index, None) is not None:
                embedding_cache.free(item.cache_key, None)

    if miss_items:
        with coordinator.encoding() if coordinator is not None else nullcontext():
            miss_item_list = [item for _, item, _ in miss_items]
            _move_items_to_device(miss_item_list, device, data_embedding_func)
            all_miss_embedding = data_embedding_func(miss_item_list)

            if isinstance(all_miss_embedding, list):
                # Per-item embeddings: no split needed, and each cache entry owns
                # its storage (a torch.split view would pin the whole concatenated
                # buffer for as long as any single item stays cached).
                assert len(all_miss_embedding) == len(miss_items), (
                    f"per-item embedding count {len(all_miss_embedding)} != "
                    f"cache-miss item count {len(miss_items)}"
                )
                split_embeddings = [
                    emb.reshape(-1, emb.shape[-1]) for emb in all_miss_embedding
                ]
            else:
                all_miss_embedding = all_miss_embedding.reshape(
                    -1, all_miss_embedding.shape[-1]
                )
                # Split output by per-item token count
                token_counts = [n for _, _, n in miss_items]
                split_embeddings = torch.split(all_miss_embedding, token_counts, dim=0)

            for (idx, item, expected_token_count), emb in zip(
                miss_items, split_embeddings
            ):
                if embedding_cache.set(item.cache_key, EmbeddingResult(embedding=emb)):
                    cached = embedding_cache.get_single(item.cache_key)
                    if _embedding_token_count(cached.embedding) == expected_token_count:
                        emb = cached.embedding
                cached_embeddings[idx] = emb

    return [
        _slice_item_chunk(cached_embeddings[idx], item, chunk_start, extend_seq_len)
        for idx, item, _ in overlapping
    ]


def _assemble_per_image_chunk(
    overlapping: List[Tuple[int, MultimodalDataItem, int]],
    hash_to_embedding: Dict[Tuple[bytes, int], torch.Tensor],
    extend_prefix_len: int,
    extend_seq_len: int,
) -> List[torch.Tensor]:
    """
    Return ordered item slices for one request from pre-computed embeddings.
    All overlapping items must already have their embeddings in hash_to_embedding.
    """
    return [
        _slice_item_chunk(
            hash_to_embedding[(item.cache_key, token_count)],
            item,
            extend_prefix_len,
            extend_seq_len,
        )
        for _idx, item, token_count in overlapping
    ]


def _get_chunked_prefill_embedding(
    data_embedding_func: DataEmbeddingFunc,
    embedding_items: List[MultimodalDataItem],
    items_size: List[int],
    prefix_length: List[int],
    extend_length: List[int],
    items_offset_list: List[List[Tuple[int, int]]],
    input_ids: torch.Tensor,
) -> tuple[torch.Tensor | None, torch.Tensor]:
    """
    Chunked prefill embedding: encode items across all requests and extract
    per-request chunks. Images from all requests are batched into a single
    ViT call for efficiency.
    """
    device = input_ids.device
    # FIXME(Xinyuan): temporary workaround for eagle3
    max_iterations = min(len(items_size) - 1, len(prefix_length))

    # Phase 0: classify requests into per-image vs full/EVS path
    per_image_requests = []  # batched ViT encoding
    full_path_requests = []  # per-request encoding (EVS etc.)
    all_chunks: List[Tuple[int, torch.Tensor]] = []

    for i in range(max_iterations):
        if items_size[i] == items_size[i + 1]:
            continue
        embedding_items_per_req = embedding_items[items_size[i] : items_size[i + 1]]
        items_offset = items_offset_list[i]
        assert items_offset is not None, items_offset

        extend_prefix_len = prefix_length[i]
        extend_seq_len = extend_length[i] if i < len(extend_length) else 0
        if extend_seq_len <= 0:
            continue

        # Multi-span items (e.g. videos) use the full encoder path below.
        # Do not encode them for chunks before, after, or between their spans.
        if not any(
            end >= extend_prefix_len and start < extend_prefix_len + extend_seq_len
            for start, end in items_offset
        ):
            continue

        req_info = PerImageRequestInfo(
            req_idx=i,
            items=embedding_items_per_req,
            items_offset=items_offset,
            extend_prefix_len=extend_prefix_len,
            extend_seq_len=extend_seq_len,
        )

        # Audio items may span several runs (interleaved with transcript text).
        is_per_image = all(
            len(item.offsets) == 1 or item.is_audio()
            for item in embedding_items_per_req
        )
        if is_per_image:
            if _is_hip or _is_xpu:
                # ROCm CI regressed with one large cross-request ViT batch; keep
                # the previous per-request path on HIP/XPU while CUDA and NPU use batching.
                chunk_slices = _get_chunked_embedding_by_item(
                    data_embedding_func,
                    embedding_items_per_req,
                    extend_prefix_len,
                    extend_seq_len,
                    device,
                )
                all_chunks.extend((i, chunk) for chunk in chunk_slices)
            else:
                per_image_requests.append(req_info)
        else:
            full_path_requests.append(req_info)

    # Phase 1: batch encode all per-image cache misses in ONE ViT call
    hash_to_embedding: Dict[Tuple[bytes, int], torch.Tensor] = {}
    if per_image_requests or image_dp_group(data_embedding_func) is not None:
        hash_to_embedding = _batch_encode_per_image_misses(
            data_embedding_func, per_image_requests, device
        )

    # Phase 2: assemble per-request chunks in original request order
    for req_info in per_image_requests:
        chunk_slices = _assemble_per_image_chunk(
            req_info.overlapping,
            hash_to_embedding,
            req_info.extend_prefix_len,
            req_info.extend_seq_len,
        )
        all_chunks.extend((req_info.req_idx, chunk) for chunk in chunk_slices)

    for req_info in full_path_requests:
        chunk_embedding, input_ids = _get_chunked_embedding_full(
            data_embedding_func,
            req_info.items,
            req_info.items_offset,
            req_info.extend_prefix_len,
            req_info.extend_seq_len,
            input_ids,
            device,
        )
        if chunk_embedding is not None:
            all_chunks.append((req_info.req_idx, chunk_embedding))

    # Sort by original request index to maintain correct output order
    all_chunks.sort(key=lambda x: x[0])
    embedding_list = [chunk for _, chunk in all_chunks]

    if len(embedding_list) == 0:
        return None, input_ids
    if len(embedding_list) == 1:
        return embedding_list[0], input_ids
    return torch.concat(embedding_list, dim=0), input_ids


def _get_multimodal_mask(
    input_ids: torch.Tensor, placeholder_tensor: torch.Tensor
) -> torch.Tensor:
    # placeholder_tensor arrives sorted from embed_mm_inputs. torch.isin
    # brute-forces only while P < 10 * N**0.145 (P placeholders, N ids); past
    # that it sorts with unique(), whose count syncs the host. The sorted
    # lookup never syncs.
    assert placeholder_tensor.numel() > 0
    placeholders = placeholder_tensor.to(input_ids.dtype)
    idx = torch.searchsorted(placeholders, input_ids)
    idx.clamp_(max=placeholders.numel() - 1)
    return (placeholders[idx] == input_ids).unsqueeze(-1)


def _count_mm_tokens_in_extend(
    prefix_length: List[int],
    extend_length: List[int],
    items_offset_list: List[List[Tuple[int, int]]],
) -> int:
    """Count MM placeholders from host offsets without reading back the GPU mask."""
    num_mm_tokens = 0
    for i, (extend_start, items_offset) in enumerate(
        zip(prefix_length, items_offset_list)
    ):
        extend_end = extend_start + (extend_length[i] if i < len(extend_length) else 0)
        for item_start, item_end in items_offset:
            overlap_start = max(item_start, extend_start)
            overlap_end = min(item_end + 1, extend_end)
            num_mm_tokens += max(overlap_end - overlap_start, 0)

    return num_mm_tokens


def _adjust_embedding_length(
    embedding: torch.Tensor,
    num_mm_tokens_in_input_ids: int,
    logger,
) -> torch.Tensor:
    num_mm_tokens_in_embedding = embedding.shape[0]
    if num_mm_tokens_in_input_ids != num_mm_tokens_in_embedding:
        logger.warning(
            f"Number of tokens in multimodal embedding does not match those in the input text. "
            f"Got {num_mm_tokens_in_input_ids} tokens in the text but {num_mm_tokens_in_embedding} "
            f"tokens from multimodal embeddings."
        )
        if num_mm_tokens_in_input_ids < num_mm_tokens_in_embedding:
            chunked_prefill_size = get_schedule().chunked_prefill_size
            if chunked_prefill_size != -1:
                logger.warning(
                    "You may want to avoid this issue by raising `chunked_prefill_size`, or disabling chunked prefill"
                )
            # extract from the end: this is a compromise
            if embedding.dim() == 2:
                embedding = embedding[-num_mm_tokens_in_input_ids:, :]
            else:
                num_multimodal = num_mm_tokens_in_input_ids // embedding.shape[0]
                embedding = embedding[-num_multimodal:, :]
        else:
            raise RuntimeError(
                f"Insufficient multimodal embedding length: {num_mm_tokens_in_input_ids=} vs {num_mm_tokens_in_embedding=}. This is an internal error"
            )
    return embedding


def get_embedding_and_mask(
    data_embedding_func: DataEmbeddingFunc,
    embedding_items: List[MultimodalDataItem],
    placeholder_tensor: torch.Tensor,
    input_ids: torch.Tensor,
    items_size: List[int],
    prefix_length: List[int],
    extend_length: List[int],
    items_offset_list: List[List[Tuple[int, int]]],
) -> Tuple[torch.Tensor | None, torch.Tensor | None, torch.Tensor]:
    """
    Generate multimodal embeddings and create a mask for identifying their positions in the input sequence.

    Args:
        data_embedding_func: Function that generates embeddings for multimodal items
        embedding_items: List of multimodal items to embed
        placeholder_tensor: Tensor containing token IDs that serve as placeholders for multimodal content
        input_ids: The input token IDs tensor
        items_size: Cumulative sizes of multimodal items per request
        prefix_length: Prefix lengths for each request
        extend_length: Sequence lengths for each request
        items_offset_list: List of offset ranges for multimodal items in each request

    Returns:
        A tuple containing:
        - The generated embeddings tensor
        - A boolean mask tensor indicating where these embeddings should be placed
        - If EVS is used, the pruned input ids tensor; otherwise, the original input ids tensor
    """
    original_input_ids = input_ids
    num_mm_tokens_in_input_ids = _count_mm_tokens_in_extend(
        prefix_length,
        extend_length,
        items_offset_list,
    )

    # 1. Get embedding
    embedding = _get_precomputed_embedding(
        embedding_items, items_size, prefix_length, extend_length, items_offset_list
    )
    if embedding is None:
        embedding, input_ids = _get_chunked_prefill_embedding(
            data_embedding_func,
            embedding_items,
            items_size,
            prefix_length,
            extend_length,
            items_offset_list,
            input_ids,
        )
        if embedding is None:
            return None, None, input_ids
    # 2. Get mask
    if _is_npu:
        torch.npu.current_stream().synchronize()
    special_multimodal_mask = _get_multimodal_mask(input_ids, placeholder_tensor)
    # 3. Adjust embedding length if needed
    if input_ids is not original_input_ids:
        # EVS rewrites placeholder spans after pruning, making the original offsets stale.
        num_mm_tokens_in_input_ids = special_multimodal_mask.sum().item()
    else:
        maybe_assert_sum(
            special_multimodal_mask,
            num_mm_tokens_in_input_ids,
            "MM placeholder count derived from offsets does not match input_ids",
        )
    embedding = _adjust_embedding_length(embedding, num_mm_tokens_in_input_ids, logger)
    return embedding, special_multimodal_mask, input_ids
